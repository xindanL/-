let font;
let path;
let codeLines = [];
let codeCount = 10;

function preload() {
  font = loadFont('assets/SourceCodePro-Regular.otf');
}

function setup() {
  createCanvas(800, 600);
  background(0);

  // Generate random JavaScript code lines
  for (let i = 0; i < codeCount; i++) {
    let code = generateCodeLine();
    codeLines.push(code);
  }

  // Create path for the skirt
  path = createSkirtPath();
}

function draw() {
  background(0);

  // Draw skirt
  drawSkirt();

  // Draw code
  drawCode();
}

// Function to generate random JavaScript code line
function generateCodeLine() {
  let keywords = ['function', 'let', 'var', 'const', 'if', 'else', 'for', 'while', 'return', 'console.log'];
  let types = ['int', 'string', 'boolean', 'object', 'Array', 'function'];
  let operators = ['=', '==', '===', '!=', '!==', '+', '-', '*', '/', '&&', '||', '!', '<', '>', '<=', '>='];
  let identifiers = ['x', 'y', 'i', 'j', 'k', 'data', 'result', 'temp', 'value'];

  let code = '';
  let lineLength = floor(random(5, 15));
  for (let i = 0; i < lineLength; i++) {
    let choice = floor(random(4));
    switch (choice) {
      case 0:
        code += random(keywords) + ' ';
        break;
      case 1:
        code += random(types) + ' ';
        break;
      case 2:
        code += random(identifiers) + ' ';
        break;
      case 3:
        code += random(operators) + ' ';
        break;
    }
  }
  code += ';';
  return code;
}

// Function to create path for the skirt
function createSkirtPath() {
  let path = [];
  let segments = 100;
  let skirtHeight = height / 2;
  for (let i = 0; i < segments; i++) {
    let x = map(i, 0, segments - 1, 0, width);
    let y = height - noise(i * 0.1, frameCount * 0.01) * skirtHeight;
    path.push(createVector(x, y));
  }
  return path;
}

// Function to draw the skirt
function drawSkirt() {
  noFill();
  strokeWeight(2);
  stroke(255, 150, 150);

  beginShape();
  for (let i = 0; i < path.length; i++) {
    vertex(path[i].x, path[i].y);
  }
  endShape();
}

// Function to draw the generated code lines
function drawCode() {
  fill(0, 200, 0);
  noStroke();
  textFont(font);
  textSize(16);
  for (let i = 0; i < codeLines.length; i++) {
    text(codeLines[i], 20, 20 + i * 20);
  }
}
